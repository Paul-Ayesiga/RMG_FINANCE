<?php

namespace App\Livewire\CustomerFolder;

use Livewire\Component;

class RMGPAY extends Component
{
   
    public function render()
    {
        return view('livewire.customer-folder.r-m-g-p-a-y');
    }
}
